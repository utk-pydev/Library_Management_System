package org.example;

import java.util.*;

public class ParkingLot {
/*
    Int No_of_slots
    List Vehicles
    Const Int totalColor = 5;
    priority_queue unoccupied_Slots[totalColor];
    HashMap<SlotNo, String>slotVehicle;
*/
    private int noOfSlots;
    private HashMap<Vehicle, Integer> curVehicleList;
    private static final int totalColors = 5;

    private PriorityQueue<Integer>unoccupiedSlots;
    private  HashMap<Integer, Vehicle>slotVehicle;

    private HashMap<Colors, Set<Vehicle>>colorSlot;

    private static ParkingLot single_instance = null;
    private ParkingLot(int noOfSlots){
        this.noOfSlots = noOfSlots;
        this.slotVehicle = new HashMap<Integer, Vehicle>();
        this.curVehicleList = new HashMap<Vehicle, Integer>();
        this.unoccupiedSlots = new PriorityQueue<Integer>();
    }

    public static ParkingLot getInstance(int noOfSlots){
        if(single_instance == null){
            single_instance = new ParkingLot(noOfSlots);
        }
        return single_instance;
    }
/*
    public List<String> getSlotsForColor(Colors color){
        for (colorSlot:
             ) {

        }
    }
*/
    public boolean addVehicle(Vehicle curVehicle){
        if(curVehicleList.containsKey(curVehicle)){
            return false;
        }
        if(!unoccupiedSlots.isEmpty()) {
            Integer put = curVehicleList.put(curVehicle, 1);
            Integer topValue = unoccupiedSlots.poll();
            slotVehicle.put(topValue, curVehicle);
         ;
            if(colorSlot.containsKey(curVehicle.getColor())) {
                Set<Vehicle>set = colorSlot.get(curVehicle.getColor());
                set.add(curVehicle);
            }
            else{
                Set<Vehicle> set = new HashSet<Vehicle>();
                set.add(curVehicle);
                colorSlot.put(curVehicle.getColor(),set);
            }
            return true;
        }
        return  false;
    }

    public  boolean deleteVehicle(Vehicle curVehicle)
    {
        if(curVehicleList.containsKey(curVehicle)){
            curVehicleList.remove(curVehicle);
            return true;
        }
        return false;
    }

}
