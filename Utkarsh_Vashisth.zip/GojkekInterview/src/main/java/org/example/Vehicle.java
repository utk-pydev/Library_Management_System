package org.example;

public class Vehicle {
    private String registrationNo;
    private Colors color;

    public Vehicle(String registrationNo, Colors color){
        this.registrationNo = registrationNo;
        this.color = color;
    }

    public Colors getColor(){
        return this.color;
    }

}
