package org.example;

public class Ticket {

    private static Integer curId = 1;
    private String vehicleId;
    private int slot_no;

    private int id;

    public Ticket(String vehicleId, int slot_no){
        this.vehicleId = vehicleId;
        this.id = ++curId;
        this.slot_no = slot_no;
    }

    public int getId(){
        return id;
    }

}
