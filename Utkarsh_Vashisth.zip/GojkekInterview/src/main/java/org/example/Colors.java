package org.example;

public enum Colors {
    RED,
    BLUE,
    ORANGE,
    YELLOW
}
