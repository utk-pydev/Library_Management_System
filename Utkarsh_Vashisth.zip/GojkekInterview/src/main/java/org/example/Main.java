package org.example;

import java.util.*;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        Scanner myObj = new Scanner(System.in);
        String cur = "";

        boolean isValid = true;

        while(isValid){
            cur = myObj.nextLine();
            System.out.println(cur);
            ParkingLot obj;
            obj = null;
            switch (cur){
                case "create_parking_lot":
                    int slots = myObj.nextInt();
                    System.out.println(slots);
                    obj = ParkingLot.getInstance(slots);
                    break;
                case "park":
                    String regNo = myObj.nextLine();
                    String color = myObj.nextLine();

                    Vehicle newObj = new Vehicle(regNo, Colors.BLUE);
                    boolean b = obj.addVehicle(newObj);
                    if(b){
                        System.out.println("Successfully parked");
                    }
                    else{
                        System.out.println("Unsuccessful Parking");
                    }
                    break;
                case "leave":

                    break;

                case "status":

                    break;
                case "registration_numbers_for_cars_with_colour":

                    break;
                case "exit":
                    isValid = false;
                    break;
                default:
                    System.out.println("Please Enter Valid Input");
            }

        }


    }
}